# Demonstration
from policeholder import Policyholder
from Payment import Payment
from Product import Product 
#Create two policyholders 
policyholder_1 = Policyholder("Miriam" , "H001")
policyholder_2 = Policyholder("Alex" , "H002")

#Create product
product = Product ("Insurance Plan", "P001", 500 )
# Process payments for policyholders
payment_1 = Payment(policyholder_1 , product)
payment_2 = Payment(policyholder_2 ,product)
# Display account details
payment_1.process_payment(500)
payment_2.process_payment(400)

print (policyholder_1.display_details())
print (policyholder_2.display_details())
# Suspend a policyholder
policyholder_2.suspend()
print (policyholder_2.display_details())
